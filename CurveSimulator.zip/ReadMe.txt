This program is simulating Interpolating Polynomials in 3D

Move Camera: WASD, Direction Key
Full screen: F