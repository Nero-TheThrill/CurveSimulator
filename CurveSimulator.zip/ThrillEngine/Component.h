#pragma once
class Component
{
};